/* Plik konfiguracyjny do programu z wlasciwosciami tablicy obslugujacych obrazy */

#ifndef MAX
#define MAX_SKALA_SZAROSCI  256  /* Maksymalna skala szarosci */
#define MAX 512          /* Maksymalny rozmiar wczytywanego obrazu */
#define DL_LINII 1024     /* Dlugosc buforow pomocniczych */
#endif
