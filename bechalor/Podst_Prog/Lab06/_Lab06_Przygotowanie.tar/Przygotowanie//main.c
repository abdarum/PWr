#include "funkcje.h"

int main(){

  char[DL_LINI];
  t_elem *stos;
  stos=(t_elem*)malloc(sizeof(t_elem));

  inicjuj(&stos);

  printf("Podaj dzialanie w RPN");
  scanf("%s",);

}
